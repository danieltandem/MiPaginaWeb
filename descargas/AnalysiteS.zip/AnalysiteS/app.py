from flask import Flask, render_template, request, send_from_directory, session
import subprocess
import os
import requests
from datetime import datetime
import webbrowser
import threading
import time
import socket
import ssl
import hashlib
from pathlib import Path
import urllib.parse
import tkinter as tk
from tkinter import filedialog
import json

app = Flask(__name__)
app.secret_key = 'analysites_secret_key_2024'
REPORTS_DIR = "reports"
os.makedirs(REPORTS_DIR, exist_ok=True)

# Herramientas integradas que NO requieren instalación
INTEGRATED_TOOLS = {
    "web_scanner": {
        "en": "Website security headers and SSL analyzer",
        "es": "Analizador de headers de seguridad y SSL para sitios web"
    },
    "port_scanner": {
        "en": "Network port scanner with service detection", 
        "es": "Escáner de puertos de red con detección de servicios"
    },
    "malware_checker": {
        "en": "File hash generator and basic malware analysis",
        "es": "Generador de hash de archivos y análisis básico de malware"
    },
    "ssl_analyzer": {
        "en": "SSL/TLS certificate security analyzer",
        "es": "Analizador de seguridad de certificados SSL/TLS"
    }
}

def extract_domain_from_url(url):
    """Extrae el dominio de una URL completa"""
    try:
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        parsed = urllib.parse.urlparse(url)
        domain = parsed.netloc
        
        # Remover puerto si existe
        if ':' in domain:
            domain = domain.split(':')[0]
            
        return domain
    except:
        return url

def check_website_security(url):
    """Escáner web integrado - Sin dependencias externas"""
    try:
        # Normalizar URL
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        results = []
        results.append(f"🔍 Security Analysis for: {url}")
        results.append("=" * 50)
        
        # Verificar SSL/HTTPS
        if url.startswith('https://'):
            results.append("✅ HTTPS Enabled (SSL/TLS)")
        else:
            results.append("❌ HTTP Only - No SSL Encryption")
        
        # Headers de seguridad
        try:
            response = requests.get(url, timeout=10, verify=False)
            security_headers = {
                'X-Frame-Options': 'Clickjacking Protection',
                'X-Content-Type-Options': 'MIME Sniffing Protection', 
                'Strict-Transport-Security': 'HSTS Enforcement',
                'Content-Security-Policy': 'XSS Protection',
                'X-XSS-Protection': 'XSS Filter'
            }
            
            results.append("\n🔒 Security Headers Analysis:")
            headers_found = 0
            for header, description in security_headers.items():
                if header in response.headers:
                    results.append(f"  ✅ {header}: {response.headers[header]}")
                    headers_found += 1
                else:
                    results.append(f"  ❌ {header}: Missing - {description}")
                    
            # Server information
            if 'Server' in response.headers:
                results.append(f"\n🖥️  Server: {response.headers['Server']}")
                
        except requests.RequestException as e:
            results.append(f"⚠️  Could not fetch headers: {str(e)}")
            headers_found = 0
        
        # Calcular puntuación
        security_score = 2  # Base score
        
        if url.startswith('https://'):
            security_score += 3
            
        security_score += min(headers_found, 5)  # Máximo 5 puntos por headers
        
        results.append(f"\n🎯 Security Score: {security_score}/10")
        
        if security_score >= 7:
            results.append("💚 Good security configuration")
        elif security_score >= 4:
            results.append("💛 Moderate security - improvements needed")
        else:
            results.append("❤️  Poor security - immediate action required")
            
        results.append("\n💡 Recommendations:")
        results.append("  - Enable missing security headers")
        results.append("  - Ensure HSTS is properly configured")
        results.append("  - Regular security audits recommended")
        
        return "\n".join(results)
        
    except Exception as e:
        return f"❌ Error during security scan: {str(e)}"

def port_scanner(target, ports="80,443,22,21,53,8080,8443"):
    """Escáner de puertos integrado"""
    try:
        results = []
        results.append(f"🔍 Port Scan Results for: {target}")
        results.append("=" * 40)
        
        port_list = [int(p.strip()) for p in ports.split(',')]
        open_ports = []
        
        for port in port_list:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((target, port))
            sock.close()
            
            if result == 0:
                # Servicios comunes
                service_names = {
                    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
                    53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP",
                    443: "HTTPS", 993: "IMAPS", 995: "POP3S", 
                    3389: "RDP", 8080: "HTTP-Alt", 8443: "HTTPS-Alt"
                }
                service = service_names.get(port, "Unknown")
                results.append(f"✅ Port {port}/tcp OPEN - {service}")
                open_ports.append(port)
            else:
                results.append(f"❌ Port {port}/tcp CLOSED")
        
        results.append(f"\n📊 Summary: {len(open_ports)}/{len(port_list)} ports open")
        
        if open_ports:
            results.append("💡 Security Note: Review open ports for unnecessary services")
                
        return "\n".join(results)
        
    except Exception as e:
        return f"❌ Error during port scan: {str(e)}"

def malware_hash_checker(file_path):
    """Verificador de malware usando hash analysis"""
    try:
        if not os.path.exists(file_path):
            return "❌ ERROR: File not found. Please check the path and try again."
        
        # Verificar permisos de lectura
        try:
            with open(file_path, 'rb') as test_file:
                test_file.read(1)
        except PermissionError:
            return "❌ ERROR: Permission denied. Run as Administrator or choose a different file."
        except IOError as e:
            return f"❌ ERROR: Cannot access file - {str(e)}"
        
        # Calcular hash del archivo
        results = []
        results.append(f"🔍 Malware Analysis for: {file_path}")
        results.append("=" * 50)
        
        file_stats = os.stat(file_path)
        file_size = file_stats.st_size
        file_extension = Path(file_path).suffix.lower()
        
        # Calcular diferentes hashes
        hashers = {
            'MD5': hashlib.md5(),
            'SHA-1': hashlib.sha1(),
            'SHA-256': hashlib.sha256()
        }
        
        with open(file_path, 'rb') as f:
            while chunk := f.read(8192):
                for hasher in hashers.values():
                    hasher.update(chunk)
        
        results.append(f"📁 File Size: {file_size:,} bytes")
        results.append(f"📄 Extension: {file_extension}")
        results.append(f"📅 Created: {datetime.fromtimestamp(file_stats.st_ctime)}")
        results.append(f"✏️  Modified: {datetime.fromtimestamp(file_stats.st_mtime)}")
        
        results.append("\n🔐 File Hashes:")
        for name, hasher in hashers.items():
            results.append(f"  {name}: {hasher.hexdigest()}")
        
        # Análisis de seguridad básico
        results.append("\n⚠️  Security Assessment:")
        
        # Extensiones sospechosas
        suspicious_extensions = ['.exe', '.bat', '.cmd', '.ps1', '.vbs', '.scr', '.pif', '.com']
        if file_extension in suspicious_extensions:
            results.append("  ❌ Suspicious: Executable file type detected")
            results.append("  💡 Recommendation: Scan with antivirus software")
        else:
            results.append("  ✅ Normal: Common document/file type")
        
        # Tamaño sospechoso
        if file_size > 100 * 1024 * 1024:  # 100MB
            results.append("  ⚠️  Warning: Very large file - unusual for executables")
        elif file_size < 100:  # 100 bytes
            results.append("  ⚠️  Warning: Very small file - potential malware stub")
        else:
            results.append("  ✅ Normal: Reasonable file size")
            
        results.append("\n💡 For complete analysis:")
        results.append("Upload file to: https://www.virustotal.com/")
        results.append(f"Or check SHA-256: {hashers['SHA-256'].hexdigest()}")
        
        return "\n".join(results)
        
    except Exception as e:
        return f"❌ ERROR: Analysis failed - {str(e)}"

def ssl_analyzer(domain_input):
    """Analizador SSL/TLS integrado - Corregido para URLs completas"""
    try:
        import datetime
        
        # Extraer dominio de la URL si es necesario
        domain = extract_domain_from_url(domain_input)
        
        results = []
        results.append(f"🔍 SSL/TLS Analysis for: {domain}")
        results.append("=" * 40)
        
        # Verificar certificado SSL
        context = ssl.create_default_context()
        
        try:
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    
                    # Información del certificado
                    results.append("✅ SSL Certificate Found")
                    
                    # Fecha de expiración
                    exp_date = datetime.datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                    days_until_expiry = (exp_date - datetime.datetime.now()).days
                    
                    results.append(f"📅 Valid From: {cert['notBefore']}")
                    results.append(f"📅 Expires: {cert['notAfter']}")
                    
                    if days_until_expiry < 0:
                        results.append(f"❌ Certificate EXPIRED {abs(days_until_expiry)} days ago!")
                    elif days_until_expiry < 30:
                        results.append(f"❌ Certificate expires in {days_until_expiry} days!")
                    elif days_until_expiry < 90:
                        results.append(f"⚠️  Certificate expires in {days_until_expiry} days")
                    else:
                        results.append(f"✅ {days_until_expiry} days until expiration")
                    
                    # Información del sujeto
                    subject = dict(x[0] for x in cert['subject'])
                    issuer = dict(x[0] for x in cert['issuer'])
                    
                    results.append(f"🏢 Issued To: {subject.get('commonName', 'Unknown')}")
                    results.append(f"🏛️  Issued By: {issuer.get('organizationName', 'Unknown')}")
                    
                    # Cifrados
                    cipher = ssock.cipher()
                    if cipher:
                        results.append(f"🔐 Cipher: {cipher[0]}")
                        results.append(f"🔑 Protocol: {cipher[1]}")
                        results.append(f"📏 Bits: {cipher[2]}")
                        
        except ssl.SSLError as e:
            results.append(f"❌ SSL Error: {str(e)}")
        except socket.gaierror as e:
            results.append(f"❌ DNS Error: Cannot resolve domain '{domain}'")
            results.append("💡 Check the domain name or try without https://")
        except socket.timeout:
            results.append("❌ Connection timeout - server may be down or blocking connections")
        except ConnectionRefusedError:
            results.append("❌ Connection refused - server may not have SSL enabled")
        except Exception as e:
            results.append(f"❌ Connection failed: {str(e)}")
        
        results.append("\n💡 Recommendations:")
        results.append("  - Renew certificate before expiration")
        results.append("  - Use strong cipher suites")
        results.append("  - Enable HSTS for better security")
            
        return "\n".join(results)
        
    except Exception as e:
        return f"❌ ERROR: SSL analysis failed - {str(e)}"

def get_file_path_dialog():
    """Abre un diálogo para seleccionar archivo (solo para Windows)"""
    try:
        root = tk.Tk()
        root.withdraw()  # Ocultar ventana principal
        root.attributes('-topmost', True)  # Mantener arriba
        
        file_path = filedialog.askopenfilename(
            title="Select file for analysis",
            filetypes=[
                ("All files", "*.*"),
                ("Executables", "*.exe;*.msi;*.bat;*.cmd;*.ps1"),
                ("Documents", "*.pdf;*.doc;*.docx;*.xls;*.xlsx"),
                ("Scripts", "*.js;*.py;*.php;*.html;*.htm")
            ]
        )
        root.destroy()
        return file_path
    except Exception as e:
        return None

@app.before_request
def set_default_language():
    if 'language' not in session:
        session['language'] = 'en'

@app.route("/", methods=["GET", "POST"])
def index():
    output = ""
    selected_tool = ""
    report_filename = ""
    error_message = ""
    file_selected_path = ""

    if request.method == "POST":
        selected_tool = request.form.get("tool")

        # Manejar selección de archivo
        if selected_tool == "malware_checker" and 'file_select' in request.form:
            file_path = get_file_path_dialog()
            if file_path:
                file_selected_path = file_path
                session['last_file_path'] = file_path
            else:
                error_message = "No file selected" if session.get('language') == 'en' else "No se seleccionó ningún archivo"

        elif selected_tool == "web_scanner":
            target_url = request.form.get("web_scanner_url")
            if target_url:
                output = check_website_security(target_url)
                if output.startswith("❌"):
                    error_message = output
            else:
                error_message = "You must provide a URL." if session.get('language') == 'en' else "Debes proporcionar una URL."

        elif selected_tool == "port_scanner":
            target_host = request.form.get("port_scanner_host")
            ports = request.form.get("port_scanner_ports", "80,443,22,21,53,8080,8443")
            if target_host:
                output = port_scanner(target_host, ports)
                if output.startswith("❌"):
                    error_message = output
            else:
                error_message = "You must provide a host." if session.get('language') == 'en' else "Debes proporcionar un host."

        elif selected_tool == "malware_checker":
            file_path = request.form.get("malware_checker_path", session.get('last_file_path', ''))
            if file_path:
                output = malware_hash_checker(file_path)
                if output.startswith("❌ ERROR"):
                    error_message = output
            else:
                error_message = "You must select a file." if session.get('language') == 'en' else "Debes seleccionar un archivo."

        elif selected_tool == "ssl_analyzer":
            domain = request.form.get("ssl_analyzer_domain")
            if domain:
                output = ssl_analyzer(domain)
                if output.startswith("❌"):
                    error_message = output
            else:
                error_message = "You must provide a domain." if session.get('language') == 'en' else "Debes proporcionar un dominio."

        # Guardar reporte si no hay error
        if output and not output.startswith("❌"):
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            report_filename = f"{selected_tool}_{timestamp}.txt"
            report_path = os.path.join(REPORTS_DIR, report_filename)
            
            with open(report_path, "w", encoding='utf-8') as f:
                f.write(output)

    return render_template("index.html", 
                         output=output, 
                         selected_tool=selected_tool, 
                         report_filename=report_filename,
                         descriptions=INTEGRATED_TOOLS,
                         language=session.get('language', 'en'),
                         error_message=error_message,
                         file_selected_path=file_selected_path or session.get('last_file_path', ''))

@app.route("/switch_language/<lang>")
def switch_language(lang):
    if lang in ['en', 'es']:
        session['language'] = lang
    return '', 204

@app.route("/download/<filename>")
def download_report(filename):
    return send_from_directory(REPORTS_DIR, filename, as_attachment=True)

def open_browser():
    time.sleep(3)
    webbrowser.open('http://localhost:5000')

if __name__ == "__main__":
    print("=" * 70)
    print("🎯 ANALYSITES - INTEGRATED SECURITY TOOLS PLATFORM")
    print("=" * 70)
    print("✅ NO INSTALLATIONS REQUIRED - Everything works immediately!")
    print("✅ SIN INSTALACIONES - ¡Todo funciona inmediatamente!")
    print("")
    print("🔧 Available Tools / Herramientas Disponibles:")
    print("   🌐 Web Security Scanner")
    print("   🔌 Network Port Scanner") 
    print("   🛡️  Malware File Analyzer")
    print("   🔒 SSL/TLS Certificate Analyzer")
    print("")
    print("🌍 The application will open automatically in your browser...")
    print("🌍 La aplicación se abrirá automáticamente en tu navegador...")
    print("=" * 70)
    print("⚡ Starting server on http://localhost:5000")
    print("🛑 Press CTRL+C to stop / Presiona CTRL+C para detener")
    print("=" * 70)
    
    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()
    
    app.run(host="0.0.0.0", port=5000, debug=False)