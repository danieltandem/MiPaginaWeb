#!/bin/bash

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "========================================"
echo "        LOGSICO - VISOR DE LOGS v2.1"
echo "========================================"
echo -e "${NC}"
echo ""

# Navegar al directorio del script
cd "$(dirname "$0")"

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}ERROR: Python3 no está instalado.${NC}"
    echo "Descargue Python desde: https://python.org"
    echo ""
    read -p "Presiona Enter para salir..."
    exit 1
fi

# Verificar PyQt5
echo "Verificando dependencias..."
python3 -c "import PyQt5" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Instalando PyQt5..."
    pip3 install PyQt5 --user
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}Intentando con pip estándar...${NC}"
        pip install PyQt5 --user
    fi
    echo ""
fi

# Crear logo si no existe
if [ ! -f "LogsICO_Logo.png" ]; then
    echo "Creando logo profesional..."
    python3 crear_logo.py
fi

# Verificar si estamos en macOS y necesitar permisos
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo -e "${YELLOW}🔍 Sistema macOS detectado${NC}"
    # Para logs de seguridad en macOS podríamos necesitar permisos
fi

# Verificar si estamos en Linux
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo -e "${YELLOW}🐧 Sistema Linux detectado${NC}"
    # Verificar si tenemos permisos para logs del sistema
    if [ ! -r "/var/log/syslog" ] && [ "$EUID" -ne 0 ]; then
        echo -e "${YELLOW}ℹ️ Para logs completos del sistema, ejecuta con sudo:${NC}"
        echo -e "${BLUE}  sudo ./Iniciar_LogViewer.sh${NC}"
        echo ""
    fi
fi

echo -e "${GREEN}Iniciando LogsICO v2.1...${NC}"
echo ""

# Ejecutar la aplicación
python3 LogsICO.py

echo ""
echo "Aplicación cerrada."