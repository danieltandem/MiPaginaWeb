import sys
import os
import subprocess
import platform
import datetime
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
                             QWidget, QTextEdit, QPushButton, QComboBox, 
                             QLabel, QFileDialog, QMenuBar, QMenu, QAction, 
                             QLineEdit, QMessageBox, QStatusBar, QGroupBox,
                             QDialog, QVBoxLayout, QTextBrowser, QDialogButtonBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPixmap, QPainter
from PyQt5.QtPrintSupport import QPrintDialog, QPrinter

class HelpDialog(QDialog):
    def __init__(self, title, content, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setGeometry(200, 200, 800, 600)
        self.setup_ui(content)
        
    def setup_ui(self, content):
        layout = QVBoxLayout(self)
        
        # Área de texto con scroll
        text_browser = QTextBrowser()
        text_browser.setHtml(content)
        text_browser.setOpenExternalLinks(True)
        text_browser.setStyleSheet("""
            QTextBrowser {
                background-color: #1E1E1E;
                color: #D4D4D4;
                border: 1px solid #404040;
                border-radius: 6px;
                padding: 15px;
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: 12px;
            }
        """)
        
        # Botones
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(self.accept)
        
        layout.addWidget(text_browser)
        layout.addWidget(button_box)

class AboutDialog(QDialog):
    def __init__(self, title, content, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setGeometry(200, 200, 600, 500)
        self.setup_ui(content)
        
    def setup_ui(self, content):
        layout = QVBoxLayout(self)
        
        # Área de texto
        text_browser = QTextBrowser()
        text_browser.setHtml(content)
        text_browser.setOpenExternalLinks(True)
        text_browser.setStyleSheet("""
            QTextBrowser {
                background-color: #1E1E1E;
                color: #D4D4D4;
                border: 1px solid #404040;
                border-radius: 6px;
                padding: 20px;
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: 12px;
            }
        """)
        
        # Botones
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(self.accept)
        
        layout.addWidget(text_browser)
        layout.addWidget(button_box)

class LogsICOViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LogsICO - Visor de Logs Profesional")
        self.setGeometry(100, 100, 1200, 800)
        
        # Configuración de idioma
        self.language = "es"
        self.texts = {
            "es": {
                "title": "LogsICO - Visor de Logs Profesional",
                "system": "📊 Logs del Sistema",
                "application": "📱 Logs de Aplicación", 
                "security": "🔒 Logs de Seguridad",
                "custom": "📂 Archivo Personalizado",
                "select_file": "📁 Seleccionar Archivo",
                "refresh": "🔄 Actualizar",
                "clear": "🗑️ Limpiar",
                "search": "🔍 Buscar...",
                "save": "💾 Guardar Logs",
                "file_menu": "Archivo",
                "exit": "Salir",
                "view_menu": "Ver",
                "language_menu": "Idioma",
                "help_menu": "Ayuda",
                "about": "Acerca de",
                "spanish": "🇪🇸 Español",
                "english": "🇺🇸 Inglés",
                "loading": "⏳ Cargando...",
                "no_logs": "📭 No hay logs para mostrar",
                "save_title": "Guardar Logs",
                "save_success": "✅ Logs guardados exitosamente",
                "save_error": "❌ Error al guardar los logs",
                "admin_required": "🔐 Se requieren permisos de administrador",
                "about_title": "Acerca de LogsICO",
                "about_text": """<div style="font-family: 'Segoe UI', Arial, sans-serif;">
                    <h1 style="color: #64B5F6; text-align: center; margin-bottom: 20px;">LogsICO</h1>
                    <h2 style="color: #E0E0E0; text-align: center; margin-bottom: 30px;">Visor de Logs Profesional v2.1</h2>
                    
                    <p style="color: #B0B0B0; line-height: 1.6; margin-bottom: 25px;">
                    Una aplicación profesional para visualizar y analizar logs del sistema 
                    con interfaz moderna y soporte multiplataforma.
                    </p>

                    <h3 style="color: #64B5F6; border-bottom: 1px solid #404040; padding-bottom: 8px;">🚀 Características Principales</h3>
                    <ul style="color: #D4D4D4; line-height: 1.8; margin-bottom: 25px;">
                    <li><strong>📊 Visualización completa</strong> - Logs del sistema, aplicación y seguridad</li>
                    <li><strong>🌍 Soporte multiplataforma</strong> - Windows, Linux y macOS</li>
                    <li><strong>🎨 Interfaz moderna</strong> - Diseño profesional oscuro</li>
                    <li><strong>🔍 Búsqueda inteligente</strong> - Filtrado en tiempo real</li>
                    <li><strong>💾 Exportación</strong> - Guardado de logs en archivos</li>
                    <li><strong>🌐 Bilingüe</strong> - Interfaz en español e inglés</li>
                    </ul>

                    <h3 style="color: #64B5F6; border-bottom: 1px solid #404040; padding-bottom: 8px;">🛠️ Tecnologías</h3>
                    <p style="color: #B0B0B0;">
                    Desarrollado con <strong>Python 3</strong> y <strong>PyQt5</strong><br>
                    Compatible con Python 3.7+
                    </p>

                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #404040; text-align: center;">
                    <p style="color: #808080; font-size: 11px;">
                    © 2024 LogsICO - Todos los derechos reservados
                    </p>
                    </div>
                </div>""",
                "help_title": "Ayuda - Cómo usar LogsICO",
                "help_text": """<div style="font-family: 'Segoe UI', Arial, sans-serif;">
                    <h1 style="color: #64B5F6; text-align: center; margin-bottom: 10px;">Guía de Usuario</h1>
                    <h2 style="color: #E0E0E0; text-align: center; margin-bottom: 30px;">LogsICO - Visor de Logs Profesional</h2>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">🎯 1. Selección de Tipo de Log</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>📊 Sistema:</strong> Logs del sistema operativo y eventos del kernel</li>
                        <li><strong>📱 Aplicación:</strong> Logs de programas y aplicaciones instaladas</li>
                        <li><strong>🔒 Seguridad:</strong> Logs de auditoría, autenticación y eventos de seguridad</li>
                        <li><strong>📂 Personalizado:</strong> Cargar archivo de log manualmente desde tu sistema</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">⚙️ 2. Funcionalidades Disponibles</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>🔄 Actualizar:</strong> Obtener los logs más recientes del sistema</li>
                        <li><strong>💾 Guardar:</strong> Exportar los logs actuales a un archivo de texto</li>
                        <li><strong>🗑️ Limpiar:</strong> Vaciar el área de visualización</li>
                        <li><strong>🔍 Buscar:</strong> Filtrar logs por texto específico en tiempo real</li>
                        <li><strong>📁 Seleccionar:</strong> Cargar archivo de log personalizado</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">💡 3. Consejos Prácticos</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li>Utilice la búsqueda para encontrar errores o eventos específicos rápidamente</li>
                        <li>Los logs se actualizan automáticamente al cambiar entre tipos</li>
                        <li>Puede cambiar el idioma en cualquier momento desde el menú 'Idioma'</li>
                        <li>Guarde logs importantes para análisis posteriores o reportes</li>
                        <li>Para logs de seguridad en Windows, ejecute como administrador</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">🔧 4. Soporte Multiplataforma</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>Windows:</strong> Event Viewer logs via PowerShell</li>
                        <li><strong>Linux:</strong> System logs desde /var/log/ y journalctl</li>
                        <li><strong>macOS:</strong> System logs via comando log</li>
                    </ul>
                    </div>

                    <div style="margin-top: 30px; padding: 15px; background: rgba(255, 193, 7, 0.1); border-radius: 5px; border-left: 4px solid #FFC107;">
                    <p style="color: #FFD54F; margin: 0;">
                    <strong>💡 Nota:</strong> Para acceder a los logs de seguridad en Windows, 
                    ejecute la aplicación como administrador.
                    </p>
                    </div>
                </div>"""
            },
            "en": {
                "title": "LogsICO - Professional Log Viewer", 
                "system": "📊 System Logs",
                "application": "📱 Application Logs",
                "security": "🔒 Security Logs", 
                "custom": "📂 Custom File",
                "select_file": "📁 Select File",
                "refresh": "🔄 Refresh",
                "clear": "🗑️ Clear",
                "search": "🔍 Search...",
                "save": "💾 Save Logs",
                "file_menu": "File",
                "exit": "Exit",
                "view_menu": "View",
                "language_menu": "Language",
                "help_menu": "Help",
                "about": "About",
                "spanish": "🇪🇸 Spanish",
                "english": "🇺🇸 English", 
                "loading": "⏳ Loading...",
                "no_logs": "📭 No logs to display",
                "save_title": "Save Logs",
                "save_success": "✅ Logs saved successfully",
                "save_error": "❌ Error saving logs",
                "admin_required": "🔐 Administrator privileges required",
                "about_title": "About LogsICO",
                "about_text": """<div style="font-family: 'Segoe UI', Arial, sans-serif;">
                    <h1 style="color: #64B5F6; text-align: center; margin-bottom: 20px;">LogsICO</h1>
                    <h2 style="color: #E0E0E0; text-align: center; margin-bottom: 30px;">Professional Log Viewer v2.1</h2>
                    
                    <p style="color: #B0B0B0; line-height: 1.6; margin-bottom: 25px;">
                    A professional application for viewing and analyzing system logs 
                    with modern interface and cross-platform support.
                    </p>

                    <h3 style="color: #64B5F6; border-bottom: 1px solid #404040; padding-bottom: 8px;">🚀 Key Features</h3>
                    <ul style="color: #D4D4D4; line-height: 1.8; margin-bottom: 25px;">
                    <li><strong>📊 Complete Viewing</strong> - System, application and security logs</li>
                    <li><strong>🌍 Cross-Platform</strong> - Windows, Linux and macOS</li>
                    <li><strong>🎨 Modern Interface</strong> - Professional dark design</li>
                    <li><strong>🔍 Smart Search</strong> - Real-time filtering</li>
                    <li><strong>💾 Export</strong> - Log saving capabilities</li>
                    <li><strong>🌐 Bilingual</strong> - English and Spanish interface</li>
                    </ul>

                    <h3 style="color: #64B5F6; border-bottom: 1px solid #404040; padding-bottom: 8px;">🛠️ Technologies</h3>
                    <p style="color: #B0B0B0;">
                    Developed with <strong>Python 3</strong> and <strong>PyQt5</strong><br>
                    Compatible with Python 3.7+
                    </p>

                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #404040; text-align: center;">
                    <p style="color: #808080; font-size: 11px;">
                    © 2024 LogsICO - All rights reserved
                    </p>
                    </div>
                </div>""",
                "help_title": "Help - How to use LogsICO",
                "help_text": """<div style="font-family: 'Segoe UI', Arial, sans-serif;">
                    <h1 style="color: #64B5F6; text-align: center; margin-bottom: 10px;">User Guide</h1>
                    <h2 style="color: #E0E0E0; text-align: center; margin-bottom: 30px;">LogsICO - Professional Log Viewer</h2>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">🎯 1. Log Type Selection</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>📊 System:</strong> Operating system logs and kernel events</li>
                        <li><strong>📱 Application:</strong> Installed programs and applications logs</li>
                        <li><strong>🔒 Security:</strong> Audit, authentication and security events</li>
                        <li><strong>📂 Custom:</strong> Manually load log file from your system</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">⚙️ 2. Available Functions</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>🔄 Refresh:</strong> Get the latest system logs</li>
                        <li><strong>💾 Save:</strong> Export current logs to a text file</li>
                        <li><strong>🗑️ Clear:</strong> Clear the display area</li>
                        <li><strong>🔍 Search:</strong> Filter logs by specific text in real-time</li>
                        <li><strong>📁 Select:</strong> Load custom log file</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">💡 3. Practical Tips</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li>Use search to quickly find specific errors or events</li>
                        <li>Logs update automatically when switching between types</li>
                        <li>You can change language anytime from the 'Language' menu</li>
                        <li>Save important logs for later analysis or reporting</li>
                        <li>For security logs on Windows, run as administrator</li>
                    </ul>
                    </div>

                    <h3 style="color: #64B5F6; background: rgba(100, 181, 246, 0.1); padding: 10px; border-radius: 5px;">🔧 4. Cross-Platform Support</h3>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 5px;">
                    <ul style="color: #D4D4D4; line-height: 1.8;">
                        <li><strong>Windows:</strong> Event Viewer logs via PowerShell</li>
                        <li><strong>Linux:</strong> System logs from /var/log/ and journalctl</li>
                        <li><strong>macOS:</strong> System logs via log command</li>
                    </ul>
                    </div>

                    <div style="margin-top: 30px; padding: 15px; background: rgba(255, 193, 7, 0.1); border-radius: 5px; border-left: 4px solid #FFC107;">
                    <p style="color: #FFD54F; margin: 0;">
                    <strong>💡 Note:</strong> To access security logs on Windows, 
                    run the application as administrator.
                    </p>
                    </div>
                </div>"""
            }
        }
        
        self.current_logs = ""
        self.setup_ui()
        self.apply_professional_theme()
        
    def setup_ui(self):
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # Barra de menú
        self.create_menu()
        
        # Grupo de controles
        controls_group = QGroupBox("🎛️ Controles Principales")
        controls_layout = QHBoxLayout(controls_group)
        
        # Selector de tipo de log
        self.log_combo = QComboBox()
        self.log_combo.addItem(self.texts[self.language]["system"], "system")
        self.log_combo.addItem(self.texts[self.language]["application"], "application")
        self.log_combo.addItem(self.texts[self.language]["security"], "security")
        self.log_combo.addItem(self.texts[self.language]["custom"], "custom")
        self.log_combo.currentIndexChanged.connect(self.on_log_type_changed)
        
        # Botón para archivos
        self.file_btn = QPushButton(self.texts[self.language]["select_file"])
        self.file_btn.clicked.connect(self.select_log_file)
        self.file_btn.setVisible(False)
        
        # Búsqueda
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText(self.texts[self.language]["search"])
        self.search_box.textChanged.connect(self.filter_logs)
        
        # Botones de acción
        self.refresh_btn = QPushButton(self.texts[self.language]["refresh"])
        self.refresh_btn.clicked.connect(self.refresh_logs)
        
        self.save_btn = QPushButton(self.texts[self.language]["save"])
        self.save_btn.clicked.connect(self.save_logs)
        
        self.clear_btn = QPushButton(self.texts[self.language]["clear"])
        self.clear_btn.clicked.connect(self.clear_logs)
        
        # Botón de ayuda
        self.help_btn = QPushButton("❓ " + ("Ayuda" if self.language == "es" else "Help"))
        self.help_btn.clicked.connect(self.show_help)
        
        # Añadir controles
        controls_layout.addWidget(QLabel("📋 Tipo de Log:"))
        controls_layout.addWidget(self.log_combo)
        controls_layout.addWidget(self.file_btn)
        controls_layout.addWidget(QLabel("🔍 Filtrar:"))
        controls_layout.addWidget(self.search_box)
        controls_layout.addWidget(self.refresh_btn)
        controls_layout.addWidget(self.save_btn)
        controls_layout.addWidget(self.clear_btn)
        controls_layout.addWidget(self.help_btn)
        controls_layout.addStretch()
        
        # Área de texto para logs
        log_group = QGroupBox("📊 Visualización de Logs")
        log_layout = QVBoxLayout(log_group)
        self.log_display = QTextEdit()
        self.log_display.setFont(QFont("Consolas", 9))
        self.log_display.setReadOnly(True)
        log_layout.addWidget(self.log_display)
        
        # Barra de estado
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.update_status()
        
        # Añadir al layout principal
        layout.addWidget(controls_group)
        layout.addWidget(log_group)
        
        # Cargar logs iniciales
        QTimer.singleShot(100, self.load_initial_logs)
    
    def create_menu(self):
        menubar = self.menuBar()
        
        # Menú Archivo
        file_menu = menubar.addMenu("📁 " + self.texts[self.language]["file_menu"])
        
        save_action = QAction("💾 " + self.texts[self.language]["save"], self)
        save_action.triggered.connect(self.save_logs)
        file_menu.addAction(save_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("🚪 " + self.texts[self.language]["exit"], self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Menú Idioma
        lang_menu = menubar.addMenu("🌐 " + self.texts[self.language]["language_menu"])
        es_action = QAction(self.texts[self.language]["spanish"], self)
        es_action.triggered.connect(lambda: self.change_language("es"))
        en_action = QAction(self.texts[self.language]["english"], self)  
        en_action.triggered.connect(lambda: self.change_language("en"))
        lang_menu.addAction(es_action)
        lang_menu.addAction(en_action)
        
        # Menú Ayuda
        help_menu = menubar.addMenu("❓ " + self.texts[self.language]["help_menu"])
        about_action = QAction("ℹ️ " + self.texts[self.language]["about"], self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def change_language(self, lang):
        self.language = lang
        self.setWindowTitle(self.texts[lang]["title"])
        self.retranslate_ui()
        self.help_btn.setText("❓ " + ("Ayuda" if lang == "es" else "Help"))
    
    def retranslate_ui(self):
        # Actualizar ComboBox
        current_type = self.log_combo.currentData()
        self.log_combo.blockSignals(True)
        self.log_combo.clear()
        self.log_combo.addItem(self.texts[self.language]["system"], "system")
        self.log_combo.addItem(self.texts[self.language]["application"], "application")
        self.log_combo.addItem(self.texts[self.language]["security"], "security")
        self.log_combo.addItem(self.texts[self.language]["custom"], "custom")
        
        # Restaurar selección
        for i in range(self.log_combo.count()):
            if self.log_combo.itemData(i) == current_type:
                self.log_combo.setCurrentIndex(i)
                break
        self.log_combo.blockSignals(False)
        
        # Actualizar botones
        self.file_btn.setText(self.texts[self.language]["select_file"])
        self.refresh_btn.setText(self.texts[self.language]["refresh"])
        self.save_btn.setText(self.texts[self.language]["save"])
        self.clear_btn.setText(self.texts[self.language]["clear"])
        self.search_box.setPlaceholderText(self.texts[self.language]["search"])
        
        # Actualizar menús
        menubar = self.menuBar()
        
        # Actualizar menú Archivo
        file_menu = menubar.actions()[0].menu()
        file_menu.setTitle("📁 " + self.texts[self.language]["file_menu"])
        file_actions = file_menu.actions()
        file_actions[0].setText("💾 " + self.texts[self.language]["save"])
        file_actions[2].setText("🚪 " + self.texts[self.language]["exit"])
        
        # Actualizar menú Idioma
        lang_menu = menubar.actions()[1].menu()
        lang_menu.setTitle("🌐 " + self.texts[self.language]["language_menu"])
        
        # Actualizar menú Ayuda
        help_menu = menubar.actions()[2].menu()
        help_menu.setTitle("❓ " + self.texts[self.language]["help_menu"])
        help_actions = help_menu.actions()
        help_actions[0].setText("ℹ️ " + self.texts[self.language]["about"])
        
        self.update_status()
    
    def update_status(self):
        system = platform.system()
        version = platform.version()
        admin_status = "🔐 Admin" if self.is_admin() else "👤 User"
        status = f"🖥️ {system} {version} | {admin_status} | 🌐 {self.language.upper()} | 📊 LogsICO v2.1"
        self.status_bar.showMessage(status)
    
    def is_admin(self):
        """Verifica si la aplicación tiene privilegios de administrador"""
        try:
            if platform.system() == "Windows":
                import ctypes
                return ctypes.windll.shell32.IsUserAnAdmin()
            else:
                return os.geteuid() == 0
        except:
            return False
    
    def apply_professional_theme(self):
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #2C2C2C, stop: 1 #1E1E1E);
                color: #E0E0E0;
            }
            QGroupBox {
                font-weight: bold;
                font-size: 11px;
                color: #FFFFFF;
                border: 2px solid #404040;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 12px;
                background-color: rgba(54, 54, 54, 0.8);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 2px 10px 2px 10px;
                color: #64B5F6;
                font-weight: bold;
            }
            QTextEdit {
                background-color: #1E1E1E;
                color: #D4D4D4;
                border: 2px solid #404040;
                border-radius: 6px;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 10px;
                padding: 10px;
                selection-background-color: #1976D2;
            }
            QPushButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #1976D2, stop: 1 #1565C0);
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: bold;
                min-width: 90px;
                font-size: 11px;
            }
            QPushButton:hover {
                background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #1E88E5, stop: 1 #1976D2);
            }
            QPushButton:pressed {
                background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #1565C0, stop: 1 #0D47A1);
            }
            QComboBox {
                background-color: #424242;
                color: white;
                border: 1px solid #555555;
                padding: 8px;
                border-radius: 5px;
                min-width: 200px;
                font-size: 11px;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox QAbstractItemView {
                background-color: #424242;
                color: white;
                selection-background-color: #1976D2;
                border: 1px solid #555555;
            }
            QLineEdit {
                background-color: #424242;
                color: white;
                border: 1px solid #555555;
                padding: 8px;
                border-radius: 5px;
                min-width: 220px;
                font-size: 11px;
            }
            QMenuBar {
                background-color: #2C2C2C;
                color: #E0E0E0;
                border-bottom: 1px solid #404040;
                font-weight: bold;
            }
            QMenuBar::item {
                padding: 6px 12px;
                background-color: transparent;
                border-radius: 4px;
            }
            QMenuBar::item:selected {
                background-color: #1976D2;
            }
            QMenu {
                background-color: #424242;
                color: white;
                border: 1px solid #555555;
                border-radius: 6px;
            }
            QMenu::item {
                padding: 8px 25px;
            }
            QMenu::item:selected {
                background-color: #1976D2;
                border-radius: 4px;
            }
            QStatusBar {
                background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,
                    stop: 0 #3C3C3C, stop: 1 #2C2C2C);
                color: #B0B0B0;
                border-top: 1px solid #404040;
                font-size: 10px;
            }
            QLabel {
                color: #E0E0E0;
                font-weight: bold;
                font-size: 11px;
            }
        """)
    
    def on_log_type_changed(self, index):
        log_type = self.log_combo.currentData()
        self.file_btn.setVisible(log_type == "custom")
        if log_type != "custom":
            self.refresh_logs()
    
    def load_initial_logs(self):
        self.log_display.setPlainText("🚀 " + self.texts[self.language]["loading"])
        self.refresh_logs()
    
    def refresh_logs(self):
        log_type = self.log_combo.currentData()
        
        if log_type == "system":
            logs = self.get_system_logs()
        elif log_type == "application":
            logs = self.get_application_logs()
        elif log_type == "security":
            logs = self.get_security_logs()
        else:
            return
        
        self.current_logs = logs if logs and logs.strip() else "📭 " + self.texts[self.language]["no_logs"]
        self.log_display.setPlainText(self.current_logs)
    
    def get_system_logs(self):
        system = platform.system()
        try:
            if system == "Windows":
                result = subprocess.run(
                    ["powershell", "-Command", 
                     "Get-EventLog -LogName System -Newest 30 | "
                     "Select-Object TimeGenerated, EntryType, Source, @{Name='Message';Expression={$_.Message -replace '\r\n', ' '}} | "
                     "Format-Table -Wrap -AutoSize"],
                    capture_output=True, text=True, timeout=20, encoding='utf-8'
                )
                if result.returncode == 0:
                    return f"📊 LOGS DEL SISTEMA - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs del sistema:\n{result.stderr}"
            
            elif system == "Linux":
                logs = []
                
                # Intentar con journalctl primero (sistemas modernos)
                try:
                    result = subprocess.run(
                        ["journalctl", "--no-pager", "-n", "50", "--priority", "0..5"],
                        capture_output=True, text=True, timeout=10
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return f"📊 LOGS DEL SISTEMA LINUX (journalctl) - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                except:
                    pass
                
                # Fuentes de logs tradicionales
                log_sources = [
                    ("/var/log/syslog", "syslog"),
                    ("/var/log/messages", "messages"), 
                                        ("/var/log/kern.log", "kernel"),
                    ("/var/log/dmesg", "dmesg")
                ]
                
                for log_path, log_name in log_sources:
                    if os.path.exists(log_path):
                        try:
                            result = subprocess.run(
                                ["tail", "-30", log_path],
                                capture_output=True, text=True, timeout=5
                            )
                            if result.returncode == 0 and result.stdout.strip():
                                logs.append(f"--- {log_name.upper()} ---\n{result.stdout}")
                        except:
                            continue
                
                if logs:
                    return f"📊 LOGS DEL SISTEMA LINUX - {platform.node()}\n" + "="*100 + "\n" + "\n".join(logs)
                else:
                    return "❌ No se pudieron leer los logs del sistema Linux\n\nSugerencias:\n- Ejecute con sudo para más acceso\n- Verifique que los archivos de log existan"
            
            elif system == "Darwin":
                result = subprocess.run(
                    ["log", "show", "--predicate", 'subsystem == "com.apple.system"', 
                     "--style", "syslog", "--last", "1h"],
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0:
                    return f"📊 LOGS DEL SISTEMA macOS - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs de macOS:\n{result.stderr}"
            
            else:
                return f"🔧 Sistema operativo no soportado: {system}"
                
        except Exception as e:
            return f"⚠️ Error al obtener logs del sistema: {str(e)}"
    
    def get_application_logs(self):
        system = platform.system()
        try:
            if system == "Windows":
                result = subprocess.run(
                    ["powershell", "-Command", 
                     "Get-EventLog -LogName Application -Newest 25 | "
                     "Select-Object TimeGenerated, EntryType, Source, @{Name='Message';Expression={$_.Message -replace '\r\n', ' '}} | "
                     "Format-Table -Wrap -AutoSize"],
                    capture_output=True, text=True, timeout=20, encoding='utf-8'
                )
                if result.returncode == 0:
                    return f"📱 LOGS DE APLICACIÓN - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs de aplicación:\n{result.stderr}"
            
            elif system == "Linux":
                result = subprocess.run(
                    ["journalctl", "--no-pager", "-n", "50", "--priority", "3..7"],
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0 and result.stdout.strip():
                    return f"📱 LOGS DE APLICACIÓN LINUX - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    # Fallback a logs tradicionales
                    app_logs = []
                    if os.path.exists("/var/log/auth.log"):
                        result = subprocess.run(["tail", "-30", "/var/log/auth.log"], capture_output=True, text=True)
                        if result.returncode == 0 and result.stdout.strip():
                            app_logs.append(f"--- AUTH LOG ---\n{result.stdout}")
                    
                    return f"📱 LOGS DE APLICACIÓN LINUX\n" + "="*100 + "\n" + "\n".join(app_logs) if app_logs else "No hay logs de aplicación disponibles"
            
            elif system == "Darwin":
                result = subprocess.run(
                    ["log", "show", "--predicate", 'process != "kernel"', 
                     "--style", "syslog", "--last", "30m"],
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0:
                    return f"📱 LOGS DE APLICACIÓN macOS - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs de aplicación macOS:\n{result.stderr}"
            
            else:
                return f"🔧 Sistema operativo no soportado: {system}"
                
        except Exception as e:
            return f"⚠️ Error al obtener logs de aplicación: {str(e)}"
    
    def get_security_logs(self):
        system = platform.system()
        try:
            if system == "Windows":
                # Verificar si tenemos permisos de administrador
                if not self.is_admin():
                    return f"🔐 {self.texts[self.language]['admin_required']}\n\n" \
                           f"Para ver los logs de seguridad en Windows, ejecute la aplicación como administrador.\n" \
                           f"Botón derecho → 'Ejecutar como administrador'"
                
                result = subprocess.run(
                    ["powershell", "-Command", 
                     "Get-EventLog -LogName Security -Newest 20 | "
                     "Select-Object TimeGenerated, EntryType, Source, @{Name='Message';Expression={$_.Message -replace '\r\n', ' '}} | "
                     "Format-Table -Wrap -AutoSize"],
                    capture_output=True, text=True, timeout=20, encoding='utf-8'
                )
                if result.returncode == 0:
                    return f"🔒 LOGS DE SEGURIDAD - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs de seguridad:\n{result.stderr}"
            
            elif system == "Linux":
                security_logs = []
                
                # Logs de autenticación (principal fuente de seguridad)
                auth_sources = [
                    "/var/log/auth.log",
                    "/var/log/secure", 
                    "/var/log/faillog"
                ]
                
                for auth_file in auth_sources:
                    if os.path.exists(auth_file):
                        try:
                            result = subprocess.run(
                                ["tail", "-40", auth_file], 
                                capture_output=True, text=True, timeout=5
                            )
                            if result.returncode == 0 and result.stdout.strip():
                                file_name = os.path.basename(auth_file)
                                security_logs.append(f"--- {file_name.upper()} ---\n{result.stdout}")
                        except:
                            continue
                
                # Logs de fail2ban si existe
                if os.path.exists("/var/log/fail2ban.log"):
                    try:
                        result = subprocess.run(
                            ["tail", "-20", "/var/log/fail2ban.log"], 
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0 and result.stdout.strip():
                            security_logs.append(f"--- FAIL2BAN ---\n{result.stdout}")
                    except:
                        pass
                
                # Intentar con journalctl para logs de seguridad
                try:
                    result = subprocess.run(
                        ["journalctl", "--no-pager", "-n", "30", "_TRANSPORT=audit"],
                        capture_output=True, text=True, timeout=10
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        security_logs.append(f"--- AUDIT LOGS (journalctl) ---\n{result.stdout}")
                except:
                    pass
                
                if security_logs:
                    return f"🔒 LOGS DE SEGURIDAD LINUX\n" + "="*100 + "\n" + "\n".join(security_logs)
                else:
                    return "ℹ️ No se encontraron logs de seguridad específicos\n\nSugerencias:\n- Ejecute con sudo para acceso completo\n- Los logs pueden estar en /var/log/auth.log o /var/log/secure"
            
            elif system == "Darwin":
                result = subprocess.run(
                    ["log", "show", "--predicate", 'eventMessage contains "auth" OR eventMessage contains "security"', 
                     "--style", "syslog", "--last", "1h"],
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0:
                    return f"🔒 LOGS DE SEGURIDAD macOS - {platform.node()}\n" + "="*100 + "\n" + result.stdout
                else:
                    return f"❌ Error al leer logs de seguridad macOS:\n{result.stderr}"
            
            else:
                return f"🔧 Sistema operativo no soportado: {system}"
                
        except Exception as e:
            return f"⚠️ Error al obtener logs de seguridad: {str(e)}"
    
    def filter_logs(self):
        search_text = self.search_box.text().lower()
        
        if not search_text:
            # Si no hay texto de búsqueda, mostrar logs originales
            if self.current_logs:
                self.log_display.setPlainText(self.current_logs)
            return
        
        # Filtrar líneas que contengan el texto de búsqueda
        if self.current_logs:
            lines = self.current_logs.split('\n')
            filtered_lines = [line for line in lines if search_text in line.lower()]
            result_text = '\n'.join(filtered_lines) if filtered_lines else "🔍 No se encontraron coincidencias"
            self.log_display.setPlainText(result_text)
    
    def select_log_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar archivo de log",
            "",
            "Archivos de log (*.log *.txt);;Todos los archivos (*.*)"
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                    content = file.read()
                file_name = os.path.basename(file_path)
                self.current_logs = f"📂 ARCHIVO: {file_name}\n" + "="*100 + "\n" + content
                self.log_display.setPlainText(self.current_logs)
            except Exception as e:
                self.log_display.setPlainText(f"❌ Error al leer archivo: {str(e)}")
    
    def save_logs(self):
        if not self.current_logs or self.current_logs.strip() == "📭 " + self.texts[self.language]["no_logs"]:
            QMessageBox.warning(self, self.texts[self.language]["save_title"], 
                              "No hay logs para guardar.")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            self.texts[self.language]["save_title"],
            f"logsico_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
            "Archivos de log (*.log);;Archivos de texto (*.txt);;Todos los archivos (*.*)"
        )
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as file:
                    file.write(f"LogsICO Export\n")
                    file.write(f"Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    file.write(f"Sistema: {platform.system()} {platform.version()}\n")
                    file.write(f"Tipo: {self.log_combo.currentText()}\n")
                    file.write("="*80 + "\n")
                    file.write(self.current_logs)
                
                QMessageBox.information(self, self.texts[self.language]["save_title"], 
                                      self.texts[self.language]["save_success"])
            except Exception as e:
                QMessageBox.critical(self, self.texts[self.language]["save_title"], 
                                   f"{self.texts[self.language]['save_error']}:\n{str(e)}")
    
    def clear_logs(self):
        self.log_display.clear()
        self.current_logs = ""
        self.search_box.clear()
    
    def show_about(self):
        dialog = AboutDialog(self.texts[self.language]["about_title"], 
                           self.texts[self.language]["about_text"], self)
        dialog.exec_()
    
    def show_help(self):
        dialog = HelpDialog(self.texts[self.language]["help_title"], 
                          self.texts[self.language]["help_text"], self)
        dialog.exec_()

def main():
    try:
        app = QApplication(sys.argv)
        app.setApplicationName("LogsICO")
        app.setApplicationVersion("2.1")
        app.setApplicationDisplayName("LogsICO - Professional Log Viewer")
        
        viewer = LogsICOViewer()
        viewer.show()
        sys.exit(app.exec_())
    except Exception as e:
        print(f"Error: {e}")
        input("Presiona Enter para salir...")

if __name__ == "__main__":
    main()