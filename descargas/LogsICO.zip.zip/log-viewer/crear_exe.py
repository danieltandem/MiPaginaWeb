import os
import subprocess
import sys

def crear_exe():
    print("Creando ejecutable...")
    
    # Verificar si PyInstaller está instalado
    try:
        import PyInstaller
    except ImportError:
        print("Instalando PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Crear el ejecutable
    comando = [
        'pyinstaller',
        '--name=VisorDeLogs',
        '--onefile',
        '--windowed',
        '--icon=NONE',
        'LogViewer.py'
    ]
    
    print("Ejecutando:", ' '.join(comando))
    subprocess.call(comando)
    
    print("\n¡Listo! El ejecutable está en la carpeta 'dist'")
    print("Puedes copiar 'VisorDeLogs.exe' a cualquier carpeta y ejecutarlo.")
    input("Presiona Enter para salir...")

if __name__ == "__main__":
    crear_exe()