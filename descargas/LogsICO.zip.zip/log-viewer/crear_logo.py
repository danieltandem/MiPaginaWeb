from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QPainter, QPixmap, QFont, QLinearGradient, QColor
from PyQt5.QtCore import Qt, QRect
import sys

def crear_logo():
    # Crear un pixmap para el logo
    pixmap = QPixmap(400, 200)
    pixmap.fill(Qt.transparent)
    
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    
    # Fondo con gradiente
    gradient = QLinearGradient(0, 0, 400, 200)
    gradient.setColorAt(0, QColor(25, 118, 210))  # Azul profesional
    gradient.setColorAt(1, QColor(13, 71, 161))   # Azul oscuro
    painter.setBrush(gradient)
    painter.setPen(Qt.NoPen)
    painter.drawRoundedRect(0, 0, 400, 200, 20, 20)
    
    # Icono de logs (líneas de texto)
    painter.setPen(QColor(255, 255, 255))
    painter.setFont(QFont("Consolas", 16, QFont.Bold))
    
    # Dibujar líneas que simulan logs
    line_y = 50
    for i in range(5):
        opacity = 1.0 - (i * 0.15)
        painter.setOpacity(opacity)
        if i == 0:
            painter.drawText(100, line_y, ">>> LOGS ICO")
        else:
            painter.drawText(100, line_y, f"[INFO] Linea de log {i+1}")
        line_y += 20
    
    # Texto principal
    painter.setOpacity(1.0)
    painter.setFont(QFont("Arial", 24, QFont.Bold))
    painter.drawText(QRect(0, 120, 400, 60), Qt.AlignCenter, "LogsICO")
    
    # Texto secundario
    painter.setFont(QFont("Arial", 12))
    painter.drawText(QRect(0, 160, 400, 30), Qt.AlignCenter, "Professional Log Viewer")
    
    painter.end()
    
    # Guardar el logo
    pixmap.save("LogsICO_Logo.png", "PNG")
    print("✅ Logo creado: LogsICO_Logo.png")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    crear_logo()
    app.quit()